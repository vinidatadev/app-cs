import { createContext, useContext, useEffect, useState } from 'react'
import { api } from '../apiClient'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)       // dados da tabela public.user
  const [permissoes, setPermissoes] = useState(null) // dados de user_permissoes
  const [loading, setLoading] = useState(true)

  async function fetchUserData(authUser) {
    if (!authUser) {
      setUser(null)
      setPermissoes(null)
      return
    }

    const [{ data: userData }, { data: permData }] = await Promise.all([
      api.from('user').select('*').eq('id_user', authUser.id).single(),
      api.from('user_permissoes').select('*').eq('id_user', authUser.id).maybeSingle(),
    ])

    setUser(userData || null)
    setPermissoes(permData || null)
  }

  useEffect(() => {
    let mounted = true

    async function init() {
      const { data: { session } } = await api.auth.getSession()
      if (mounted) {
        await fetchUserData(session?.user ?? null)
        setLoading(false)
      }
    }

    init()

    const { data: { subscription } } = api.auth.onAuthStateChange((_event, session) => {
      if (mounted) fetchUserData(session?.user ?? null)
    })

    return () => {
      mounted = false
      subscription.unsubscribe()
    }
  }, [])

  const logout = async () => {
    await api.auth.signOut()
    setUser(null)
    setPermissoes(null)
  }

  async function refreshUser() {
    const { data: { session } } = await api.auth.getSession()
    if (session?.user) {
      const { data } = await api.from('user').select('*').eq('id_user', session.user.id).single()
      setUser(data || null)
    }
  }

  const isAdmin = user?.nivel === 2

  // Helpers de permissão
  // nivel 2 = admin: tem tudo, ignora user_permissoes
  const perm = {
    organograma: isAdmin ? 'editor' : (permissoes?.organograma ?? 'none'),
    transacoes:  isAdmin ? 'editor' : (permissoes?.transacoes  ?? 'none'),
    capacitacao: isAdmin ? 'editor' : (permissoes?.capacitacao ?? 'none'),
    links:       isAdmin ? true     : (permissoes?.links       ?? false),
    // indicadores: acesso por setor 'Customer Service' ou admin
    indicadores: isAdmin ? 'editor' : (user?.setor === 'Customer Service' ? 'viewer' : 'none'),

    canView: (modulo) => {
      if (isAdmin) return true
      if (modulo === 'indicadores') return user?.setor === 'Customer Service'
      const v = permissoes?.[modulo]
      if (modulo === 'links') return v === true
      return v === 'viewer' || v === 'editor'
    },
    canEdit: (modulo) => {
      if (isAdmin) return true
      if (modulo === 'indicadores') return user?.setor === 'Customer Service'
      return permissoes?.[modulo] === 'editor'
    },
  }

  return (
    <AuthContext.Provider value={{ user, permissoes, perm, isAdmin, loading, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
